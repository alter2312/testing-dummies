// window.onload = function() {
//     var inputs = document.querySelectorAll('input');
//     var currentFocus;
  
//     inputs.forEach(function(input) {
//       input.addEventListener('focus', function() {
//         if (currentFocus && currentFocus.value !== '') {
//           currentFocus.focus();
//         } else {
//           currentFocus = this;
//         }
//       });
//     });
//   }