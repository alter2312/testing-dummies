function incrementNumber() {
    const input = document.getElementById('puntaje-input');
    input.stepUp();
}

function decrementNumber() {
    const input = document.getElementById('puntaje-input');
    input.stepDown();
}